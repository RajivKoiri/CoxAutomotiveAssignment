﻿using CoxAutomotiveAssignment.Core.Models;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CoxAutomotiveAssignment.Core.Proxies
{
    public class AssignmentProxy : IAssignmentProxy
    {
        public AssignmentProxy(IHttpClientFactory httpClientFactory)
        {
            HttpClient = httpClientFactory.CreateClient("CoxAutomotiveAssignment");
        }

        public HttpClient HttpClient { get; set; }

        public async Task<DatasetIdResponse> GetDatasetId()
        {
            var response = new DatasetIdResponse();

            var request = new HttpRequestMessage(HttpMethod.Get, "api/datasetId");

            var httpResponse = await HttpClient.SendAsync(request);
            if (httpResponse.IsSuccessStatusCode)
            {
                var responseString = await httpResponse.Content.ReadAsStringAsync();
                response = JsonConvert.DeserializeObject<DatasetIdResponse>(responseString);
            }

            return response;
        }

        public async Task<DealersResponse> GetDealer(string datasetId, int dealerId)
        {
            var response = new DealersResponse();

            var request = new HttpRequestMessage(HttpMethod.Get, $"api/{datasetId}/dealers/{dealerId}");

            var httpResponse = await HttpClient.SendAsync(request);
            if (httpResponse.IsSuccessStatusCode)
            {
                var responseString = await httpResponse.Content.ReadAsStringAsync();
                response = JsonConvert.DeserializeObject<DealersResponse>(responseString);
            }

            return response;
        }

        public async Task<VehicleResponse> GetVehicle(string datasetId, int vehicleId)
        {
            var response = new VehicleResponse();

            var request = new HttpRequestMessage(HttpMethod.Get, $"api/{datasetId}/vehicles/{vehicleId}");

            var httpResponse = await HttpClient.SendAsync(request);
            if (httpResponse.IsSuccessStatusCode)
            {
                var responseString = await httpResponse.Content.ReadAsStringAsync();
                response = JsonConvert.DeserializeObject<VehicleResponse>(responseString);
            }

            return response;
        }

        public async Task<VehicleIdsResponse> GetVehicleIds(string datasetId)
        {
            var response = new VehicleIdsResponse();

            var request = new HttpRequestMessage(HttpMethod.Get, $"api/{datasetId}/vehicles");

            var httpResponse = await HttpClient.SendAsync(request);
            if (httpResponse.IsSuccessStatusCode)
            {
                var responseString = await httpResponse.Content.ReadAsStringAsync();
                response = JsonConvert.DeserializeObject<VehicleIdsResponse>(responseString);
            }

            return response;
        }

        public async Task<AnswerResponse> SubmitAnswer(string datasetId, Answer answer)
        {
            var response = new AnswerResponse();

            var request = new HttpRequestMessage(HttpMethod.Post, $"api/{datasetId}/answer");

            var jsonInString = JsonConvert.SerializeObject(answer);
            var content = new StringContent(jsonInString, Encoding.UTF8, "application/json");

            var httpResponse = await HttpClient.PostAsync($"api/{datasetId}/answer", content);

            if (httpResponse.IsSuccessStatusCode)
            {
                var responseString = await httpResponse.Content.ReadAsStringAsync();
                response = JsonConvert.DeserializeObject<AnswerResponse>(responseString);
            }

            return response;
        }
    }
}
