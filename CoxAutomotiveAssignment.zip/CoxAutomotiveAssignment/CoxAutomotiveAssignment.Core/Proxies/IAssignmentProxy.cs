﻿using CoxAutomotiveAssignment.Core.Models;
using System.Threading.Tasks;

namespace CoxAutomotiveAssignment.Core.Proxies
{
    public interface IAssignmentProxy
    {
        Task<DatasetIdResponse> GetDatasetId();

        Task<VehicleIdsResponse> GetVehicleIds(string datasetId);

        Task<VehicleResponse> GetVehicle(string datasetId, int vehicleId);

        Task<DealersResponse> GetDealer(string datasetId, int dealerId);

        Task<AnswerResponse> SubmitAnswer(string datasetId, Answer answer);
    }
}
