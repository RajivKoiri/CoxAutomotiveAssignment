﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace CoxAutomotiveAssignment.Core.Models
{
    public class DealerAnswer
    {
        [JsonProperty("dealerId")]
        public int DealerId { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("vehicles")]
        public List<VehicleAnswer> Vehicles { get; set; }
    }
}
