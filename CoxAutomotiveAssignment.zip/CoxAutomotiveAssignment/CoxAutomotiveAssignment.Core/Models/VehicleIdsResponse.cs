﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace CoxAutomotiveAssignment.Core.Models
{
    public class VehicleIdsResponse
    {
        [JsonProperty("vehicleIds")]
        public List<int> VehicleIds { get; set; }
    }
}
