﻿using Newtonsoft.Json;

namespace CoxAutomotiveAssignment.Core.Models
{
    public class DatasetIdResponse
    {
        [JsonProperty("datasetId")]
        public string DatasetId { get; set; }
    }
}
