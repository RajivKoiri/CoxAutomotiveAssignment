﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace CoxAutomotiveAssignment.Core.Models
{
    public class Answer
    {
        [JsonProperty("dealers")]
        public List<DealerAnswer> Dealers { get; set; }
    }
}
