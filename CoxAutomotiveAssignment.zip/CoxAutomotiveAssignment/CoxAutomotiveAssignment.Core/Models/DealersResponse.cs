﻿using Newtonsoft.Json;

namespace CoxAutomotiveAssignment.Core.Models
{
    public class DealersResponse
    {
        [JsonProperty("dealerId")]
        public int DealerId { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }
}
