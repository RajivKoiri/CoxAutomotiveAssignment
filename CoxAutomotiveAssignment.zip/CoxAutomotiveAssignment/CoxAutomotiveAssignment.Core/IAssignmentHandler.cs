﻿using CoxAutomotiveAssignment.Core.Models;
using System.Threading.Tasks;

namespace CoxAutomotiveAssignment.Core
{
    public interface IAssignmentHandler
    {
        Task<AnswerResponse> SubmitAnswer();
    }
}
