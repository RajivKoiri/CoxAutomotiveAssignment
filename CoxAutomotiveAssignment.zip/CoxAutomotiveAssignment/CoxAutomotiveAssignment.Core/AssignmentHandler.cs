﻿using CoxAutomotiveAssignment.Core.Models;
using CoxAutomotiveAssignment.Core.Proxies;
using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading.Tasks;

namespace CoxAutomotiveAssignment.Core
{
    public class AssignmentHandler : IAssignmentHandler
    {
        public AssignmentHandler(IAssignmentProxy assignmentProxy)
        {
            AssignmentProxy = assignmentProxy;
        }

        public IAssignmentProxy AssignmentProxy { get; set; }

        public async Task<AnswerResponse> SubmitAnswer()
        {
            var st1 = DateTime.Now;
            var datasetIdResponse = await AssignmentProxy.GetDatasetId();
            var diff1 = DateTime.Now.Subtract(st1).TotalMilliseconds;

            var st2 = DateTime.Now;
            var vehicleIdsResponse = await AssignmentProxy.GetVehicleIds(datasetIdResponse.DatasetId);
            var diff2 = DateTime.Now.Subtract(st2).TotalMilliseconds;

            var vehicles = new ConcurrentBag<VehicleResponse>();
            var st3 = DateTime.Now;
            var vehicleTasks = vehicleIdsResponse.VehicleIds.Select(async vehicleId =>
            {
                var vehicleResponse = await AssignmentProxy.GetVehicle(datasetIdResponse.DatasetId, vehicleId);

                vehicles.Add(vehicleResponse);
            });
            await Task.WhenAll(vehicleTasks);
            var diff3 = DateTime.Now.Subtract(st3).TotalMilliseconds;

            var dealerIds = vehicles.Select(v => v.DealerId).Distinct().ToList();
            var dealers = new ConcurrentBag<DealersResponse>();
            var st4 = DateTime.Now;
            var dealerTasks = dealerIds.Select(async dealerId =>
            {
                var dealerResponse = await AssignmentProxy.GetDealer(datasetIdResponse.DatasetId, dealerId);

                dealers.Add(dealerResponse);
            });
            await Task.WhenAll(dealerTasks);
            var diff4 = DateTime.Now.Subtract(st3).TotalMilliseconds;

            var answer = new Answer
            {
                Dealers = dealers.Select(d => new DealerAnswer
                {
                    DealerId = d.DealerId,
                    Name = d.Name,
                    Vehicles = vehicles.Where(v => v.DealerId == d.DealerId)
                                .Select(v => new VehicleAnswer
                                {
                                    VehicleId = v.VehicleId,
                                    Make = v.Make,
                                    Model = v.Model,
                                    Year = v.Year
                                }).ToList()
                }).ToList()
            };

            var st5 = DateTime.Now;
            var response = await AssignmentProxy.SubmitAnswer(datasetIdResponse.DatasetId, answer);
            var diff5 = DateTime.Now.Subtract(st5).TotalMilliseconds;

            return response;
        }
    }
}
