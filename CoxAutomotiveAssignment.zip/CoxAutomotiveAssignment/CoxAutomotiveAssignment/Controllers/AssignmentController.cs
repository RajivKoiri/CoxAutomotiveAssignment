﻿using CoxAutomotiveAssignment.Core;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CoxAutomotiveAssignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssignmentController : ControllerBase
    {
        public AssignmentController(IAssignmentHandler assignmentHandler)
        {
            AssignmentHandler = assignmentHandler;
        }

        public IAssignmentHandler AssignmentHandler { get; set; }

        [HttpGet]
        public async Task<IActionResult> SubmitAnswer()
        {
            var response = await AssignmentHandler.SubmitAnswer();

            return Ok(response);
        }
    }
}